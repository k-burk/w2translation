package com.w2retrieval.starterproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarterProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
