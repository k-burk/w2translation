# starter-project
Capstone Paychex W-2 Retrieval starter Spring Boot project

Links to tutorials used:  
- Spring Boot Integration with MongoDB Tutorial from MongoDB website: https://www.mongodb.com/compatibility/spring-boot  
- Completed code from above tutorial: https://github.com/mongodb-developer/mongodb-springboot  
- Spring Boot + Spring Data MongoDB example: https://mkyong.com/spring-boot/spring-boot-spring-data-mongodb-example/  
- Accessing Data with MongoDB Spring Boot Guide: https://spring.io/guides/gs/accessing-data-mongodb/  
- Embedded documents with MongoDB and Spring Boot: https://lankydan.dev/2017/05/29/embedded-documents-with-spring-data-and-mongodb
